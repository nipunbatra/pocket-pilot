"""Restore the exact recorded run. Run beside run.json after extracting the ZIP."""
import base64, json
from pathlib import Path
root = Path(__file__).resolve().parent
def restore(value):
    if isinstance(value, dict):
        if set(value) == {'$image_ref'}:
            return 'data:image/png;base64,' + base64.b64encode((root / value['$image_ref']).read_bytes()).decode()
        return {k: restore(v) for k, v in value.items()}
    if isinstance(value, list):
        return [restore(v) for v in value]
    return value
target = root / 'full-comparison-run.json'
if target.exists():
    raise SystemExit('Output already exists; refusing to overwrite it.')
target.write_text(json.dumps(restore(json.loads((root / 'run.json').read_text())), ensure_ascii=False))
print(target)
