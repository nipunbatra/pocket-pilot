Run D: 189 actual attempts, including errors.
run.json contains exact recorded data except PNG data URLs, replaced by {$image_ref: path}.
Each PNG is stored once under images/. This avoids repeating image bytes hundreds of times.
Run python3 restore.py to reconstruct the original importable full-comparison-run.json.
That restored file is large. No credentials are included.
